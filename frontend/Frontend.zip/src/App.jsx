import { useEffect, useState } from 'react';
import {
  getPrograms,
  createProgram,
  getApplicants,
  createApplicant,
  getSeatMatrices,
  createSeatMatrix,
  getAdmissions,
  allocateAdmission,
  confirmAdmission,
} from './api';

const initialApplicant = {
  name: '',
  email: '',
  phone: '',
  category: '',
  entryType: '',
  quotaType: 'KCET',
  marks: 0,
  documentStatus: 'Pending',
};

const initialSeatMatrix = {
  programId: 0,
  totalIntake: 0,
  kcet: 0,
  comedk: 0,
  management: 0,
};

const initialAllocation = {
  applicantId: 0,
  programId: 0,
  quotaType: 'KCET',
};

const quotas = ['KCET', 'COMEDK', 'Management'];

function App() {
  const [programs, setPrograms] = useState([]);
  const [applicants, setApplicants] = useState([]);
  const [seatMatrices, setSeatMatrices] = useState([]);
  const [admissions, setAdmissions] = useState([]);
  const [programName, setProgramName] = useState('');
  const [applicant, setApplicant] = useState(initialApplicant);
  const [seatMatrix, setSeatMatrix] = useState(initialSeatMatrix);
  const [allocation, setAllocation] = useState(initialAllocation);
  const [message, setMessage] = useState('');

  useEffect(() => {
    loadAll();
  }, []);

  async function loadAll() {
    try {
      setPrograms(await getPrograms());
      setApplicants(await getApplicants());
      setSeatMatrices(await getSeatMatrices());
      setAdmissions(await getAdmissions());
    } catch (error) {
      setMessage(error.message || 'Failed to load data');
    }
  }

  async function handleAddProgram(e) {
    e.preventDefault();
    try {
      await createProgram({ name: programName });
      setProgramName('');
      await loadAll();
      setMessage('Program saved successfully.');
    } catch (error) {
      setMessage(error.message);
    }
  }

  async function handleAddApplicant(e) {
    e.preventDefault();
    try {
      await createApplicant(applicant);
      setApplicant(initialApplicant);
      await loadAll();
      setMessage('Applicant saved successfully.');
    } catch (error) {
      setMessage(error.message);
    }
  }

  async function handleAddSeatMatrix(e) {
    e.preventDefault();
    try {
      await createSeatMatrix({
        programId: Number(seatMatrix.programId),
        totalIntake: Number(seatMatrix.totalIntake),
        KCET: Number(seatMatrix.kcet),
        COMEDK: Number(seatMatrix.comedk),
        Management: Number(seatMatrix.management),
      });
      setSeatMatrix(initialSeatMatrix);
      await loadAll();
      setMessage('Seat matrix saved successfully.');
    } catch (error) {
      setMessage(error.message);
    }
  }

  async function handleAllocateAdmission(e) {
    e.preventDefault();
    try {
      await allocateAdmission({
        applicantId: Number(allocation.applicantId),
        programId: Number(allocation.programId),
        quotaType: allocation.quotaType,
      });
      setAllocation(initialAllocation);
      await loadAll();
      setMessage('Admission allocated successfully.');
    } catch (error) {
      setMessage(error.message);
    }
  }

  async function handleConfirm(id) {
    try {
      await confirmAdmission(id);
      await loadAll();
      setMessage('Admission confirmed.');
    } catch (error) {
      setMessage(error.message);
    }
  }

  return (
    <div className="app-shell">
      <header>
        <h1>Admission CRM</h1>
        <p>Manage programs, applicants, seats, and admission allocation.</p>
      </header>

      <div className="notice">{message}</div>

      <div className="grid">
        <section>
          <h2>Programs</h2>
          <form onSubmit={handleAddProgram} className="form-row">
            <input
              value={programName}
              onChange={(e) => setProgramName(e.target.value)}
              placeholder="Program name"
              required
            />
            <button type="submit">Add</button>
          </form>
          <ul>
            {programs.map((program) => (
              <li key={program.id}>{program.name}</li>
            ))}
          </ul>
        </section>

        <section>
          <h2>Applicants</h2>
          <form onSubmit={handleAddApplicant} className="form-column">
            <input
              value={applicant.name}
              name="name"
              onChange={(e) => setApplicant({ ...applicant, name: e.target.value })}
              placeholder="Name"
              required
            />
            <input
              value={applicant.email}
              name="email"
              onChange={(e) => setApplicant({ ...applicant, email: e.target.value })}
              placeholder="Email"
              required
            />
            <input
              value={applicant.phone}
              name="phone"
              onChange={(e) => setApplicant({ ...applicant, phone: e.target.value })}
              placeholder="Phone"
            />
            <input
              value={applicant.category}
              name="category"
              onChange={(e) => setApplicant({ ...applicant, category: e.target.value })}
              placeholder="Category"
            />
            <div className="form-row">
              <select
                value={applicant.entryType}
                onChange={(e) => setApplicant({ ...applicant, entryType: e.target.value })}
              >
                <option value="">Entry type</option>
                <option value="KCET">KCET</option>
                <option value="COMEDK">COMEDK</option>
                <option value="Management">Management</option>
              </select>
              <select
                value={applicant.quotaType}
                onChange={(e) => setApplicant({ ...applicant, quotaType: e.target.value })}
              >
                <option value="KCET">KCET</option>
                <option value="COMEDK">COMEDK</option>
                <option value="Management">Management</option>
              </select>
            </div>
            <input
              type="number"
              value={applicant.marks}
              onChange={(e) => setApplicant({ ...applicant, marks: Number(e.target.value) })}
              placeholder="Marks"
            />
            <button type="submit">Add Applicant</button>
          </form>
        </section>

        <section>
          <h2>Seat Matrix</h2>
          <form onSubmit={handleAddSeatMatrix} className="form-column">
            <select
              value={seatMatrix.programId}
              onChange={(e) => setSeatMatrix({ ...seatMatrix, programId: Number(e.target.value) })}
              required
            >
              <option value="0">Select program</option>
              {programs.map((program) => (
                <option key={program.id} value={program.id}>
                  {program.name}
                </option>
              ))}
            </select>
            <input
              type="number"
              value={seatMatrix.totalIntake}
              onChange={(e) => setSeatMatrix({ ...seatMatrix, totalIntake: Number(e.target.value) })}
              placeholder="Total intake"
              min="0"
            />
            <input
              type="number"
              value={seatMatrix.kcet}
              onChange={(e) => setSeatMatrix({ ...seatMatrix, kcet: Number(e.target.value) })}
              placeholder="KCET seats"
              min="0"
            />
            <input
              type="number"
              value={seatMatrix.comedk}
              onChange={(e) => setSeatMatrix({ ...seatMatrix, comedk: Number(e.target.value) })}
              placeholder="COMEDK seats"
              min="0"
            />
            <input
              type="number"
              value={seatMatrix.management}
              onChange={(e) => setSeatMatrix({ ...seatMatrix, management: Number(e.target.value) })}
              placeholder="Management seats"
              min="0"
            />
            <button type="submit">Save Matrix</button>
          </form>
        </section>

        <section>
          <h2>Allocation</h2>
          <form onSubmit={handleAllocateAdmission} className="form-column">
            <select
              value={allocation.applicantId}
              onChange={(e) => setAllocation({ ...allocation, applicantId: Number(e.target.value) })}
              required
            >
              <option value="0">Select applicant</option>
              {applicants.map((applicant) => (
                <option key={applicant.id} value={applicant.id}>
                  {applicant.name}
                </option>
              ))}
            </select>
            <select
              value={allocation.programId}
              onChange={(e) => setAllocation({ ...allocation, programId: Number(e.target.value) })}
              required
            >
              <option value="0">Select program</option>
              {programs.map((program) => (
                <option key={program.id} value={program.id}>
                  {program.name}
                </option>
              ))}
            </select>
            <select
              value={allocation.quotaType}
              onChange={(e) => setAllocation({ ...allocation, quotaType: e.target.value })}
            >
              {quotas.map((quota) => (
                <option key={quota} value={quota}>
                  {quota}
                </option>
              ))}
            </select>
            <button type="submit">Allocate Admission</button>
          </form>
        </section>

        <section className="wide">
          <h2>Admissions</h2>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Applicant</th>
                <th>Program</th>
                <th>Quota</th>
                <th>Status</th>
                <th>Fee</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {admissions.map((admission) => (
                <tr key={admission.id}>
                  <td>{admission.id}</td>
                  <td>{admission.applicantName}</td>
                  <td>{admission.programName}</td>
                  <td>{admission.quotaType}</td>
                  <td>{admission.isConfirmed ? 'Confirmed' : 'Pending'}</td>
                  <td>{admission.feeStatus}</td>
                  <td>
                    {!admission.isConfirmed && (
                      <button onClick={() => handleConfirm(admission.id)}>
                        Confirm
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </div>
    </div>
  );
}

export default App;
